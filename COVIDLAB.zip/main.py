import Calculator
import BookStore
from MaxQueue import MaxQueue
from DLList import DLList
from SLLQueue import SLLQueue
from SLLStack import SLLStack
from ChainedHashTable import ChainedHashTable
from BinarySearchTree import BinarySearchTree

def menu_calculator() :
    calculator =  Calculator.Calculator()
    option=""
    exp = ""
    hash_of_vars = calculator.dict
    while option != '0':
        print ("""
        1 Check mathematical expression
        2 Introduce and set expression
        3 Add variable for expression
        4 Show expression with variable values
        5 Show expression with number values
        6 Evaluate
        0 Return to main menu
        """)
        option = input()
        if option == "1":
            expression = input("Introduce the mathematical expression: ")
            if calculator.matched_expression(expression) :
                print(f"{expression} is a valid expression")
            else:
                print(f"{expression} is invalid expression")
        elif option == "2":
            expression = input("Introduce a mathematical expression: ")
            if calculator.matched_expression(expression) :
                print(f"{expression} is a valid expression")
                exp = expression
            else:
                print(f"{expression} is invalid expression")
        elif option == "3":
            key = input('Input a Key: ')
            value = input('Input a Value: ')
            hash_of_vars.add(key, float(value))
            print(f"Your variables are stored as {hash_of_vars}...")
        elif option == "4":
            print(exp)
        elif option == "5":
            print(calculator.plug_in_vars(exp))
        elif option == "6":
            print(f'Solving {calculator.plug_in_vars(exp)}...')
            print(calculator.evaluate(exp))

        ''' 
        Add the menu options when needed
        '''

def menu_isPalindrome():
    some_DLL = DLList()
    some_string = input('Enter a string to test: ')
    for i in range(len(some_string)):
        some_DLL.add(i, some_string[i])
    if some_DLL.isPalindrome():
        print(f"{some_string} is a palindrome...")
    else:
        print(f"{some_string} is not a palindrome...")

def menu_isReverse():
    user_inp = int(input("Enter 1 for SLL Queue Reversal, 2 for SLL Stack Reversal: \n"))
    if user_inp == 1:
        some_SLL = SLLQueue()
        some_string = input('Enter a string to reverse in a SLL Queue: \n')
        for i in range(len(some_string)):
            some_SLL.add(some_string[i])
        print(f"SLL before reversal is {some_SLL}.")
        some_SLL.reverse()
        print(f"SLL after reversal is {some_SLL}.")
    elif user_inp == 2:
        some_SLL = SLLStack()
        some_string = input('Enter a string to reverse in a SLL Stack: \n')
        for i in range(0, len(some_string)):
            some_SLL.push(some_string[i])
        print(f"SLL before reversal is {some_SLL}.")
        some_SLL.reverse()
        print(f"SLL after reversal is {some_SLL}.")

def menu_bookstore_system() :
    bookStore = BookStore.BookStore()
    option=""
    while option != '0':
        print("""
        s FIFO shopping cart
        r Random shopping cart
        1 Load book catalog
        2 Remove a book by index from catalog
        3 Add a book by index to shopping cart
        4 Remove from the shopping cart
        5 Search book by infix
        6 Reverse shopping cart (LAB 3)
        7 Best Selling Book in shopping cart (LAB 3)
        8 Search by index sorted title and add to shopping cart (LAB 4)
        9 Write Traversals to a file (LAB 4)
        10 Get Best Selling for a prefix (LAB 5)
        11 Binary Search By Title (LAB 6)
        12 (Quick or Merge) Sort Bookstore (LAB 6)
        13 Similar Graph Option bfs2 (LAB 7)
        14 Similar Graph Option dfs2 (LAB 7)
        0 Return to main menu
        """)
        option=input() 
        if option=="r":
            bookStore.setRandomShoppingCart()
        elif option=="s":
            bookStore.setShoppingCart()
        elif option=="1":
            file_name = input("Introduce the name of the file: ")
            bookStore.loadCatalog(file_name) 
            # bookStore.pathLength(0, 159811)
        elif option=="2":
            i = int(("Introduce the index to remove from catalog: "))
            bookStore.removeFromCatalog(i)
        elif option=="3":
            i = int(input("Introduce the index to add to shopping cart: "))
            bookStore.addBookByIndex(i)
        elif option=="4":
            bookStore.removeFromShoppingCart()
        elif option=="5":
            infix = input("Introduce the query to search: ")
            bookStore.searchBookByInfix(infix)
        elif option=="6":
            bookStore.shoppingCart.reverse()
        elif option=="7":
            mq = MaxQueue()
            for i in bookStore.shoppingCart:
                mq.add(i)
            mq.getBestSelling()
        elif option=="8":
            bookTitle = input("What Book (title) would you like to add to cart? \n")
            if bookTitle == '':
                print('None Found...')
            if bookStore.indexSortedTitle.find(bookTitle) != None:
                bookStore.shoppingCart.add(bookStore.indexSortedTitle.find(bookTitle))
                print(f"Successfully added to Shopping Cart! {bookStore.indexSortedTitle.find(bookTitle)}")
            else:
                print(f"Sorry, '{bookTitle}' was not found...")
        elif option == "9":
            choice = ""
            while choice != "0":
                print("""
                       1 in_order traversal
                       2 pre_order traversal
                       3 post_order traversal
                       4 breadth-first traversal
                       5 Height
                       0 Exit
                       """)
                choice = input()
                if choice == "1":
                    in_ord = bookStore.indexSortedTitle.in_order(bookStore.indexSortedTitle.r, [])
                    for book in in_ord:
                        with open("books-inorder.txt", 'a', encoding='utf8') as f:
                            f.write(f"\n{book.title}")
                if choice == "2":
                    pre_ord = bookStore.indexSortedTitle.pre_order(bookStore.indexSortedTitle.r, [])
                    for book in pre_ord:
                        with open("books-preorder.txt", 'a', encoding='utf8') as f:
                            f.write(f"\n{book.title}")
                if choice == "3":
                    post_ord = bookStore.indexSortedTitle.post_order(bookStore.indexSortedTitle.r, [])
                    for book in post_ord:
                        with open("books-postorder.txt", 'a', encoding='utf8') as f:
                            f.write(f"\n{book}")
                if choice == "4":
                    bf = bookStore.indexSortedTitle.bf_traverse()
                    for book in bf:
                        with open("books-bftraversal.txt", 'a', encoding='utf8') as f:
                            f.write(f"\n{book.title}")
                if choice == "5":
                    height = bookStore.indexSortedTitle.height()
                    print(f'The height of indexSortedTitle is {height}')
        elif option == "10":
            pfx = input("What prefix would you like to search for? ")
            k = int(input("How many of the top ranks would you like to display? "))
            books = bookStore.getBestSelling(pfx, k)
            print(f"\nThe top {k} Best Selling books for '{pfx}' are: \n")
            for i in range(len(books)):
                print(books[i].rank, ': ', books[i].title)
        elif option == "11":
            pfx = input("What prefix would you like to search for? ")
            bookStore.binarySearchByTitle(pfx)
        elif option == "12":
            print("""
                   1 Quick Sort BookStore
                   2 Merge Sort BookStore
                   """)
            inp = input()
            if inp == "1":
                bookStore.quick_sort_catalog()
                print('Successfully Quick Sorted Catalog!')
            elif inp == "2":
                bookStore.merge_sort_catalog()
                print('Successfully Merge Sorted Catalog!')
        elif option == "13":
            r = int(input("Enter index: "))
            k = int(input("Enter distance k from the index: "))
            print(bookStore.similarGraph.bfs2(r, k))
            print('\n')
        elif option == "14":
            r1 = int(input("Enter r1: "))
            r2 = int(input("Enter r2: "))
            print(bookStore.similarGraph.dfs2(r1, r2))
            print('\n')

def menu_BST():
        bst = BinarySearchTree()
        option = ""
        l = []
        while option != '0':
            print("""
                    1 Add to BST
                    2 Display values of nodes in_order
                    3 Display values of nodes pre_order
                    4 Display values of nodes post_order
                    5 Display values of nodes breadth-first
                    6 Display height of tree
                    0 Quit
                    """)
            option = input()
            if option == "1":
                key = input("Node: ")
                value = input("Value: ")
                bst.add(key, value)
                print(f'Successfully added {bst.find(key)}')
            if option == "2":
                li = bst.in_order(bst.r, l)
                print("In-order traversal: ", li)
            if option == "3":
                li = bst.pre_order(bst.r, l)
                print("Pre-order traversal: ", li)
            if option == "4":
                li = bst.post_order(bst.r, l)
                print("Post-order traversal: ", li)
            if option == "5":
                li = bst.bf_traverse()
                print(li)
            if option == "6":
                print(bst.height())

        ''' 
        Add the menu options when needed
        '''
#main: Create the main menu
def main() :
    option=""
    while option != '0':
        print ("""
        1 Calculator
        2 Bookstore System
        3 Palindrome
        4 Reverse
        5 Binary Search Tree Options
        0 Exit/Quit
        """)
        option=input() 
        
        if option=="1":
            menu_calculator()
        elif option=="2":
            menu_bookstore_system()
        elif option=="3":
            menu_isPalindrome()
        elif option=="4":
            menu_isReverse()
        elif option=="5":
            menu_BST()

if __name__ == "__main__":
  main()





















