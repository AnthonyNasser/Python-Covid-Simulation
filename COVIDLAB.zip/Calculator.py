import numpy as np
from ArrayStack import ArrayStack
import BinaryTree
import ChainedHashTable
import DLList
import operator

class Calculator:
    def __init__(self) :
        self.dict = ChainedHashTable.ChainedHashTable(DLList.DLList)

    def set_variable(self, k :str, v : float) :
        self.dict.add(k,v)
        
    def matched_expression(self, s : str) -> bool :
        try:
            # initialize stack to keep track of parenthesis
            stack = ArrayStack()
            for i in s:
                # add all openings to the stack
                if i == "(":
                    stack.push(i)
                elif i == ")":
                    # if theres a closing parenthesis, check if there's
                    # an adjacent opening parenthesis already stored in the stack
                    if stack.size() > 0 and ("(" == stack.get(stack.size()-1)):
                        stack.pop()
                    else:
                        return False
            # if all closing were matched w/ opening, the stack should be empty since everything was popped
            if stack.size() == 0:
                return True
            else:
                return False
        except IndexError:
            print('Index out of Bounds!')

    def introduce_expression(self, s: str):
        if self.matched_expression(s):
            print(f"The expression is \n{s}")
            return s
        else:
            print(f"The expression {s} is invalid!")
            return None

    # Works for extra credit...
    # def plug_in_vars(self, s: str, hash: ChainedHashTable):
    #     some_expression = []
    #     for i in s:
    #         if hash.find(i):
    #             temp = hash.find(i)
    #             if len(temp) > 1:
    #                 print(f'Current Values of {i}: ')
    #                 for j in temp:
    #                     print(f"{j}, ")
    #                 choice = input(f'Which value do you choose for {i}? \n ')
    #                 if float(choice) in temp:
    #                     some_expression.append(float(choice))
    #                 else:
    #                     print('That was not a valid option...')
    #                     return False
    #             else:
    #                 some_expression.append(hash.find(i)[0])
    #         elif not hash.find(i):
    #             some_expression.append(i)
    #     return "".join(str(i) for i in some_expression)

    def plug_in_vars(self, s : str):
        some_expression = []
        for i in s:
            if self.dict.find(i):
                some_expression.append(self.dict.find(i))
            else:
                some_expression.append(i)
        return "".join(str(i) for i in some_expression)

    def build_parse_tree(self, exp : str) -> str:
        if not self.matched_expression(exp):
            return None
        t = BinaryTree.BinaryTree()
        t.r = t.Node('')
        u = t.r
        for token in exp:
            if token == '(':
                u = u.insert_left()
                # u = u.left
            elif token in ['+', '-', '*', '/', '*']:
                u.x = token
                u = u.insert_right()
                # u = u.right
            elif token == ')':
                u = u.parent
            elif token.isalpha():
                u.x = token
                u = u.parent
        return t

    def _evaluate(self, root):
        op = { '+':operator.add, '-':operator.sub, '*':operator.mul, '/':operator.truediv}
        if root.left != None and root.right != None:
            w = op[root.x]
            return w(self._evaluate(root.left), self._evaluate(root.right))
        elif root.left is None and root.right is None:
            t = self.dict.find(root.x)
            if t != None:
                return t
            return root.x
        else:
            if root.left is not None:
                return self._evaluate(root.left)
            else:
                return self._evaluate(root.right)

    def evaluate(self, exp):
        try:
            parseTree = self.build_parse_tree(exp)
            return self._evaluate(parseTree.r)
        except Exception:
            print('Please enclose all expressions in parenthesis ()...')